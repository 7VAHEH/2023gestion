import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyWindowDelete extends JFrame implements ActionListener {
    StudentsDAO studentsDAO = new StudentsDAO();

    private JTextField textField = new JTextField(5);
    private JLabel jLabel = new JLabel("ID");
    private Button button = new Button("Delete");


    public MyWindowDelete() {
        setTitle("Delete");

        setLayout(new FlowLayout());
        add(jLabel);
        add(textField);
        add(button);
        button.addActionListener(this);

        setSize(800, 800);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) { //ete buttoni vra click e arvac
            int ID = Integer.parseInt(textField.getText());
            studentsDAO.delete(ID);

            MyWindow myWindow = new MyWindow();
        }
    }
}
