import java.sql.Date;

public class Main {
    public static void main(String[] args) {
        //MyWindow myWindow = new MyWindow();

        //MyWindowDeleteManyStudents myWindowDeleteManyStudents = new MyWindowDeleteManyStudents();
        //MyWindowDelete myWindowDelete= new MyWindowDelete();
        //MyWindowUpdate myWindowUpdate = new MyWindowUpdate();
        //MyWindowInsert myWindowInsert = new MyWindowInsert();
    }
}