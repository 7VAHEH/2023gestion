public class ProjectsDAO implements ImplProjects{
    @Override
    public void create(Projects projects) {

    }

    @Override
    public void read() {

    }

    @Override
    public void update(int ID, int year) {

    }

    @Override
    public void delete(int ID) {

    }
}
