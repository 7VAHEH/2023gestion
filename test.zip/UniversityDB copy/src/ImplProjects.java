public interface ImplProjects {
    public void create(Projects projects);
    public void read();
    public void update(int ID, int year);
    public void delete(int ID);
}
