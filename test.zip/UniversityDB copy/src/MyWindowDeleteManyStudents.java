import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyWindowDeleteManyStudents extends JFrame implements ActionListener {

    StudentsDAO studentsDAO = new StudentsDAO();
    private Button button = new Button("Delete Many Students");
    private JLabel jLabel = new JLabel("This button will delete all the students with name.length > 5");

    public MyWindowDeleteManyStudents() {
        setLayout(new FlowLayout());
        add(jLabel);
        add(button);
        button.addActionListener(this);

        setSize(800, 800);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            studentsDAO.deleteManyStudents();

            MyWindow myWindow = new MyWindow();
        }
    }
}
