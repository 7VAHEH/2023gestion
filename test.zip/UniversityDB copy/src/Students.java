import java.sql.Date;

public class Students {
    private int studentID;
    private String name;
    private String surname;
    private Date birthday;
    private int fee;

    public Students() {
    }

    public Students(int studentID, String name, String surname, Date birthday, int fee) {
        this.studentID = studentID;
        this.name = name;
        this.surname = surname;
        this.birthday = birthday;
        this.fee = fee;
    }

    public Students(String name, String surname, Date birthday, int fee) {
        this.name = name;
        this.surname = surname;
        this.birthday = birthday;
        this.fee = fee;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    @Override
    public String toString() {
        return "Students{" +
                "studentID=" + studentID +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", birthday=" + birthday +
                ", fee=" + fee +
                '}';
    }
}
