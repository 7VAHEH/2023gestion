import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyWindowUpdate extends JFrame implements ActionListener {
    StudentsDAO studentsDAO = new StudentsDAO();

    private JTextField textField1 = new JTextField(5);
    private JTextField textField2 = new JTextField(5);
    private JButton button = new JButton("Update");
    private JLabel id = new JLabel("ID");
    private JLabel fee = new JLabel("New Fee");

    public MyWindowUpdate() {
        setLayout(new FlowLayout());

        add(id);
        add(textField1);
        add(fee);
        add(textField2);
        add(button);
        button.addActionListener(this);

        setSize(500, 500);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            int ID = Integer.parseInt(textField1.getText());
            int fee = Integer.parseInt(textField2.getText());
            studentsDAO.update(ID, fee);

            MyWindow myWindow = new MyWindow();
        }
    }
}
