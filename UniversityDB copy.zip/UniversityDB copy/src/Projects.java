public class Projects {
    private int projectID;
    private String projectName;
    private int year;
    private int studentID;

    public Projects() {
    }

    public Projects(int projectID, String projectName, int year, int studentID) {
        this.projectID = projectID;
        this.projectName = projectName;
        this.year = year;
        this.studentID = studentID;
    }

    public int getProjectID() {
        return projectID;
    }

    public void setProjectID(int projectID) {
        this.projectID = projectID;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    @Override
    public String toString() {
        return "Projects{" +
                "projectID=" + projectID +
                ", projectName='" + projectName + '\'' +
                ", year=" + year +
                ", studentID=" + studentID +
                '}';
    }
}
