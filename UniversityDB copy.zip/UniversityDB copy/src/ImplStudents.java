public interface ImplStudents {
    public void create(Students students);
    public void read();
    public void update();
    public void delete();
}
