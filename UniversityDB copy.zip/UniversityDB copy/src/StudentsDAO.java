import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StudentsDAO implements ImplStudents {
    UniversityDB universityDB = new UniversityDB();
    List<Students> studentsList = new ArrayList<>();

    public List<Students> getStudentsList() {
        return studentsList;
    }

    @Override
    //es methody stexcum e nor usanox bazayum
    public void create(Students students) {
        String name = students.getName();
        String surname = students.getSurname();
        Date birthday = students.getBirthday();
        int fee = students.getFee();

        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "insert into students values(null, " + "'" + name + "', " + "'" + surname + "', " + "'" + birthday + "', " + fee + ")";
            //System.out.println(query);
            statement.executeUpdate(query);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    //1) read all students
    public void read() {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "select * from students";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Students students = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int fee = resultSet.getInt(5);

                students.setName(name);
                students.setSurname(surname);
                students.setBirthday(birthday);
                students.setFee(fee);

                studentsList.add(students);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //4) read only those students whose name's length is even
    public List<Students> readEvenLength() {
        List<Students> studentsWithEven = new ArrayList<>();

        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "select * from students";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Students students = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int fee = resultSet.getInt(5);

                students.setStudentID(id);
                students.setName(name);
                students.setSurname(surname);
                students.setBirthday(birthday);
                students.setFee(fee);

                if (name.length() % 2 == 0)
                    studentsWithEven.add(students);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return studentsWithEven;
    }

    //5) read only those students whose name's length is prime number
    public List<Students> readPrime() {
        List<Students> studentsWithPrime = new ArrayList<>();

        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "select * from students";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Students students = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int fee = resultSet.getInt(5);

                students.setStudentID(id);
                students.setName(name);
                students.setSurname(surname);
                students.setBirthday(birthday);
                students.setFee(fee);

                if (isPrime(name.length()))
                    studentsWithPrime.add(students);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return studentsWithPrime;
    }

    public boolean isPrime(int n) {
        if (n <= 1)
            return false;

        for (int i = 2; i < n; i++)
            if (n % i == 0)
                return false;

        return true;
    }

    public Students readMaxFee() {
        Students student = new Students();
        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "select * from students where fee = (select max(fee) from students)";
            ResultSet resultSet = statement.executeQuery(query);
            resultSet.next();

            int id = resultSet.getInt(1);
            String name = resultSet.getString(2);
            String surname = resultSet.getString(3);
            Date birthday = resultSet.getDate(4);
            int feeS = resultSet.getInt(5);

            student.setStudentID(id);
            student.setName(name);
            student.setSurname(surname);
            student.setBirthday(birthday);
            student.setFee(feeS);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return student;
    }

    //2) fee 10%ov bardzracnel
    @Override
    public void update() {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "update students set fee = fee + (fee * 10 / 100)";
            statement.executeUpdate(query);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //es methody update e anum yst ID-i ev ir tvac columny
    public void update(int ID, int fee) {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            statement.executeUpdate("update students set fee = " + fee + " where studentID = " + ID);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //3) amenabardzr fee-ov studentin jnjel
    @Override
    public void delete() {

        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query1 = "delete from students where fee =(select fee from (select max(fee) as fee from students) as temp)";
            statement.executeUpdate(query1);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //jnjum e usanoxin yst ir ID-i
    public void delete(int ID) {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            statement.executeUpdate("delete from students where studentID = " + ID);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //jnjel usanoxin um anuny 5 taric e baxkacac, ays lucman depqum petq e nayev verevi delete(int ID) methody
    public void deleteManyStudents() {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");

            while (resultSet.next()) {
                Students student = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int feeS = resultSet.getInt(5);

                student.setStudentID(id);
                student.setName(name);
                student.setSurname(surname);
                student.setBirthday(birthday);
                student.setFee(feeS);

                if (name.length() > 5) {
                    delete(id);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteMax() {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");

            int max = Integer.MIN_VALUE;

            while (resultSet.next()) {
                Students student = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int feeS = resultSet.getInt(5);

                student.setStudentID(id);
                student.setName(name);
                student.setSurname(surname);
                student.setBirthday(birthday);
                student.setFee(feeS);

                if (feeS > max) {
                    max = feeS;
                }
            }
            statement.executeUpdate("delete from students where studentID = " + max);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteMaxAge() {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "DELETE FROM students WHERE YEAR(birthday) = (SELECT MIN(year) FROM (SELECT YEAR(birthday) as year FROM students) AS subquery)";
            statement.executeUpdate(query);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Students printMaxAge() {
        Students student = new Students();
        try {
            Statement statement = universityDB.connectDB().createStatement();
            String query = "SELECT * FROM students WHERE YEAR(birthday) = (SELECT MIN(year) FROM (SELECT YEAR(birthday) as year FROM students) AS subquery)";
            ResultSet resultSet = statement.executeQuery(query);
            resultSet.next();

            int id = resultSet.getInt(1);
            String name = resultSet.getString(2);
            String surname = resultSet.getString(3);
            Date birthday = resultSet.getDate(4);
            int feeS = resultSet.getInt(5);

            student.setStudentID(id);
            student.setName(name);
            student.setSurname(surname);
            student.setBirthday(birthday);
            student.setFee(feeS);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return student;
    }

    public List<Students> workingWithDigits() {
        List<Students> studentsList = new ArrayList<>();
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");

            while (resultSet.next()) {
                Students students = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int fee = resultSet.getInt(5);

                students.setStudentID(id);
                students.setName(name);
                students.setSurname(surname);
                students.setBirthday(birthday);
                students.setFee(fee);

                if (digitSum(fee) > (name.length() + surname.length())) {
                    studentsList.add(students);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return studentsList;
    }

    //gtum e tvi tvanshanneri gumary
    public int digitSum(int n) {
        int sum = 0;
        while (n != 0) {
            int digit = n % 10;

            sum += digit;
            n = n / 10;
        }
        return sum;
    }

    public List<Students> duplicateLetter() {
        List<Students> studentsWithDuplicates = new ArrayList<>();
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");

            while (resultSet.next()) {
                Students students = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int fee = resultSet.getInt(5);

                students.setStudentID(id);
                students.setName(name);
                students.setSurname(surname);
                students.setBirthday(birthday);
                students.setFee(fee);

                // char[] names = name.toCharArray();
                name = name.toLowerCase();
                for (int i = 0; i < name.length(); i++) {
                    for (int j = i + 1; j < name.length(); j++) {
                        if (name.charAt(i) == name.charAt(j))
                            studentsWithDuplicates.add(students);
//                        if (names[i] == names[j])
//                            studentsWithDuplicates.add(students);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return studentsWithDuplicates;
    }

    public void firstLetterWithSurname() {
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");

            while (resultSet.next()) {
                Students students = new Students();

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String surname = resultSet.getString(3);
                Date birthday = resultSet.getDate(4);
                int fee = resultSet.getInt(5);

                students.setStudentID(id);
                students.setName(name);
                students.setSurname(surname);
                students.setBirthday(birthday);
                students.setFee(fee);

                System.out.println(name.charAt(0) + "." + surname);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public void alphabeticOrder() {

        //select * from students order by name; - SQL-i hraman
        read();

        for (int i = 0; i < studentsList.size(); i++) {
            for (int j = i + 1; j < studentsList.size(); j++) {
                if (studentsList.get(i).getName().compareTo(studentsList.get(j).getName()) > 0) {
                    Students temp = studentsList.get(i);
                    studentsList.set(i, studentsList.get(j));
                    studentsList.set(j, temp);
                }
            }
        }
    }

    public int rowCount() {
        int rowCountInt;
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet rowCount = statement.executeQuery("select count('studentID') from students");
            rowCount.next();
            rowCountInt = rowCount.getInt(1);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rowCountInt;
    }

    public Object[][] data() {
        Object[][] studentsData;
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData(); //durs e berum axyusaki karucvacqy

            int rowcount = rowCount();
            int columnCount = resultSetMetaData.getColumnCount();
            studentsData = new Object[rowcount][columnCount];

            for (int i = 0; resultSet.next(); i++) {
                for (int j = 0; j < columnCount; j++) {
                    studentsData[i][j] = resultSet.getObject(j + 1);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return studentsData;
    }

    public String[] columnNames() {
        String[] column;
        try {
            Statement statement = universityDB.connectDB().createStatement();
            ResultSet resultSet = statement.executeQuery("select * from students");
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

            int columnCount = resultSetMetaData.getColumnCount();
            column = new String[columnCount];

            for (int i = 0; i < column.length; i++) {
                column[i] = resultSetMetaData.getColumnName(i + 1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return column;
    }
}

