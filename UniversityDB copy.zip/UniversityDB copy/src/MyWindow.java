import javax.swing.*;
import java.awt.*;

//durs e berelu patuhani vra bolor usanoxnerin
public class MyWindow extends JFrame {
    StudentsDAO studentsDAO = new StudentsDAO();
    private JTable j;

    public MyWindow() {
        setTitle("Show Students");

        Object[][] data = studentsDAO.data();
        // Column Names
        String[] columnNames = {"studentID", "name", "surname", "birthday", "fee"};
        //String[] columnNames = studentsDAO.columnNames();
        // Initializing the JTable
        j = new JTable(data, columnNames);
        // adding it to JScrollPane
        JScrollPane sp = new JScrollPane(j); //qanon, vor karoxananq shat tvyali depqum scroll anel
        add(sp);

        setSize(1000, 1000);
        setVisible(true);
    }
}
