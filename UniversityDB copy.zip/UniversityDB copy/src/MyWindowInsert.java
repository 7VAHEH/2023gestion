import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;

public class MyWindowInsert extends JFrame implements ActionListener {
    private JTextField name = new JTextField(10);
    private JTextField surname = new JTextField(10);
    private JTextField year = new JTextField(5);
    private JTextField month = new JTextField(5);
    private JTextField day = new JTextField(5);
    private JTextField fee = new JTextField(10);

    private JLabel jLabel1 = new JLabel("Name");
    private JLabel jLabel2 = new JLabel("Surname");
    private JLabel jLabel3 = new JLabel("Year");
    private JLabel jLabel4 = new JLabel("Month");
    private JLabel jLabel5 = new JLabel("Day");
    private JLabel jLabel6 = new JLabel("Fee");

    private JButton insert = new JButton("Insert Value");

    public MyWindowInsert() {
        setTitle("Insert");

        setLayout(new FlowLayout());

        add(jLabel1);
        add(name);
        add(jLabel2);
        add(surname);
        add(jLabel3);
        add(year);
        add(jLabel4);
        add(month);
        add(jLabel5);
        add(day);
        add(jLabel6);
        add(fee);

        add(insert);
        insert.addActionListener(this);

        setSize(800, 800);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == insert) {
            String studentName = name.getText();
            String studentSurname = surname.getText();
            int birthdayYear = Integer.parseInt(year.getText());
            int birthdayMonth = Integer.parseInt(month.getText());
            int birthdayDay = Integer.parseInt(day.getText());
            int studentFee = Integer.parseInt(fee.getText());

            StudentsDAO studentsDAO = new StudentsDAO();
            studentsDAO.create(new Students(studentName, studentSurname, new Date(birthdayYear - 1900, birthdayMonth, birthdayDay), studentFee));

            MyWindow myWindow = new MyWindow();
        }
    }
}
